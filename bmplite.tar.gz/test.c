#include "bmplite.h"

int main() {
    bmp_image_t image;
    int x;
    int y;
    FILE* fp = fopen("test.bmp", "wb");

    bmp_init(&image, 400, 300);

    for(y = 0; y < 300; y++) {
        for(x = 0; x < 400; x++) {
            bmp_putpixel(&image, x,  y, color_from_rgb(
                        (int)(x / 1.5),
                        (int)((x + y) / 3.0),
                        (int)(y / 1.5)));
        }
    }
    bmp_dump(&image, fp);
    bmp_free(&image);

    fclose(fp);
    return 0;
}
