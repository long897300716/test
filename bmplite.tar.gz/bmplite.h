#ifndef BMPLITE_H_INCLUDED
#define BMPLITE_H_INCLUDED

/*
 * RichSelian's BMP image creator
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

/*
 * INTERFACE
 */
typedef struct bmp_image_t {
    uint8_t* m_bitmap;
    uint32_t m_width;
    uint32_t m_height;
} bmp_image_t;

static int bmp_init(bmp_image_t* image, uint32_t width, uint32_t height);
static int bmp_free(bmp_image_t* image);
static int bmp_dump(bmp_image_t* image, FILE* stream);

static uint32_t bmp_putpixel(bmp_image_t* image, uint32_t x, uint32_t y, uint32_t color);
static uint32_t bmp_getpixel(bmp_image_t* image, uint32_t x, uint32_t y);

#define color_from_rgb(r,g,b)   ((r)<256?((r)<<16):0xff0000) + ((g)<256?((g)<<8):0xff00) + ((b)<256?((b)<<0):0xff)
#define color_r(v)              (((v)>>16) & 0xff)
#define color_g(v)              (((v)>>8)  & 0xff)
#define color_b(v)              (((v)>>0)  & 0xff)

/*
 * IMPLEMENTATION
 */
#define bmpx_out4(f,v) (putc((v),f), putc((v)>>8,f), putc((v)>>16,f), putc((v)>>24,f))
#define bmpx_out2(f,v) (putc((v),f), putc((v)>>8,f))
#define bmpx_out1(f,v) (putc((v),f))

static inline int bmp_init(bmp_image_t* image, uint32_t width, uint32_t height) {
    if((image->m_bitmap = malloc(width * height * 3)) != NULL) {
        image->m_width = width;
        image->m_height = height;
        memset(image->m_bitmap, -1, width * height * 3);
        return 0;
    }
    return -1;
}

static inline int bmp_free(bmp_image_t* image) {
    free(image->m_bitmap);
    return 0;
}

static inline int bmp_dump(bmp_image_t* image, FILE* stream) {
    bmpx_out1(stream, 'B');                                         // magic1
    bmpx_out1(stream, 'M');                                         // magic2
    bmpx_out4(stream, image->m_width * image->m_height * 3 + 54);   // file size
    bmpx_out4(stream, 0);                                           // reserved
    bmpx_out4(stream, 54);                                          // offset of bitmap data
    bmpx_out4(stream, 40);                                          // header size
    bmpx_out4(stream, image->m_width);                              // width
    bmpx_out4(stream, image->m_height);                             // height
    bmpx_out2(stream, 1);                                           // image plains
    bmpx_out2(stream, 24);                                          // bits per pixel
    bmpx_out4(stream, 0);                                           // no compression
    bmpx_out4(stream, image->m_width * image->m_height * 3);        // bitmap data length
    bmpx_out4(stream, 3000);                                        // x pixels per meter
    bmpx_out4(stream, 3000);                                        // y pixels per meter
    bmpx_out4(stream, 0x01000000);                                  // colors
    bmpx_out4(stream, 0x01000000);                                  // important colors
    fwrite(image->m_bitmap, 1, image->m_width * image->m_height * 3, stream);
    return ferror(stream);
}

static inline uint32_t bmp_putpixel(bmp_image_t* image, uint32_t x, uint32_t y, uint32_t color) {
    if(x < image->m_width && y < image->m_height) {
        image->m_bitmap[((image->m_height - 1 - y) * image->m_width + x) * 3 + 0] = color % 256;             // B
        image->m_bitmap[((image->m_height - 1 - y) * image->m_width + x) * 3 + 1] = color / 256 % 256;       // G
        image->m_bitmap[((image->m_height - 1 - y) * image->m_width + x) * 3 + 2] = color / 256 / 256 % 256; // R
        return color;
    }
    return -1;
}

static inline uint32_t bmp_getpixel(bmp_image_t* image, uint32_t x, uint32_t y) {
    uint8_t b = image->m_bitmap[(y * image->m_width + x) * 3 + 0];
    uint8_t g = image->m_bitmap[(y * image->m_width + x) * 3 + 1];
    uint8_t r = image->m_bitmap[(y * image->m_width + x) * 3 + 2];
    return color_from_rgb(r, g, b);
}
#endif
